package hi;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Calculator implements ActionListener {
	
	boolean isOperatorClicked=false;
	String first;
	String symbol;
	float result;
	JFrame jf;
	JTextField jt;
	JButton jb0,jb1,jb2,jb3,jb4,jb5,jb6,jb7,jb8,jb9,jbDiv,jbDot,jbDiff,jbMul,jbAdd,jbEq,jbCl;
	public Calculator() {
		jf=new JFrame("CALCULATOR");
		jf.setLayout(null);
		jf.setSize(300,500);
		jf.setLocation(1000,200);
		jf.getContentPane().setBackground(Color.black);
		
		 jt=new JTextField();
		 jt.setBounds(10, 80, 270, 40);
		 jt.setHorizontalAlignment(SwingConstants.RIGHT);
		 jf.add(jt);
		
		jb7=new JButton("7");
		jb7.setBounds(10, 230, 60, 40);
		jb7.setFont(new Font("arial",Font.BOLD, 20));
		jb7.addActionListener(this);
		jf.add(jb7);
		
		
		jb8=new JButton("8");
		jb8.setBounds(80, 230, 60, 40);
		jb8.setFont(new Font("arial",Font.BOLD, 20));
		jb8.addActionListener(this);
		jf.add(jb8);
		
	    jb9=new JButton("9");
		jb9.setBounds(150, 230, 60, 40);
		jb9.setFont(new Font("arial",Font.BOLD, 20));
		jb9.addActionListener(this);
		jf.add(jb9);
		
		jb4=new JButton("4");
		jb4.setBounds(10, 290, 60, 40);
		jb4.setFont(new Font("arial",Font.BOLD, 20));
		jb4.addActionListener(this);
		jf.add(jb4);
		
		jb5=new JButton("5");
		jb5.setBounds(80, 290, 60, 40);
		jb5.setFont(new Font("arial",Font.BOLD, 20));
		jb5.addActionListener(this);
		jf.add(jb5);
		
		jb6=new JButton("6");
		jb6.setBounds(150, 290, 60, 40);
		jb6.setFont(new Font("arial",Font.BOLD, 20));
		jb6.addActionListener(this);
		jf.add(jb6);
		
		jb1=new JButton("1");
		jb1.setBounds(10, 350, 60, 40);
		jb1.setFont(new Font("arial",Font.BOLD, 20));
		jb1.addActionListener(this);
		jf.add(jb1);
		
		jb2=new JButton("2");
		jb2.setBounds(80, 350, 60, 40);
		jb2.setFont(new Font("arial",Font.BOLD, 20));
		jb2.addActionListener(this);
		jf.add(jb2);
		
		jb3=new JButton("3");
		jb3.setBounds(150, 350, 60, 40);
		jb3.setFont(new Font("arial",Font.BOLD, 20));
		jb3.addActionListener(this);
		jf.add(jb3);
		
		jb0=new JButton("0");
		jb0.setBounds(10, 410, 130, 40);
		jb0.setFont(new Font("arial",Font.BOLD, 20));
		jb0.addActionListener(this);
		jf.add(jb0);
		
		jbDot=new JButton(".");
		jbDot.setBounds(150, 410, 60, 40);
		jbDot.setFont(new Font("arial",Font.BOLD, 20));
		jbDot.addActionListener(this);
		jf.add(jbDot);
		
		jbEq=new JButton("=");
		jbEq.setBounds(220, 350, 60, 100);
		jbEq.setFont(new Font("arial",Font.BOLD, 20));
		jbEq.addActionListener(this);
		jf.add(jbEq);
		
		jbDiv=new JButton("/");
		jbDiv.setBounds(150, 170, 60, 40);
		jbDiv.setFont(new Font("arial",Font.BOLD, 20));
		jbDiv.addActionListener(this);
		jf.add(jbDiv);
		
		jbMul=new JButton("x");
		jbMul.setBounds(220, 230, 60, 40);
		jbMul.setFont(new Font("arial",Font.BOLD, 20));
		jbMul.addActionListener(this);
		jf.add(jbMul);
		
		jbDiff=new JButton("-");
		jbDiff.setBounds(220, 170, 60, 40);
		jbDiff.setFont(new Font("arial",Font.BOLD, 20));
		jbDiff.addActionListener(this);
		jf.add(jbDiff);
		
		jbAdd=new JButton("+");
		jbAdd.setBounds(220, 290, 60, 40);
		jbAdd.setFont(new Font("arial",Font.BOLD, 20));
		jbAdd.addActionListener(this);
		jf.add(jbAdd);
		
		jbCl=new JButton("C");
		jbCl.setBounds(80, 170, 60, 40);
		jbCl.setFont(new Font("arial",Font.BOLD, 20));
		jbCl.addActionListener(this);
		jf.add(jbCl);
		
		jf.setVisible(true);
		

	}
	public static void main(String arg[])
	{
		new Calculator();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource()==jb0)
		{
			if(isOperatorClicked)
			{
				jt.setText("0");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"0");
			}
		}
		else if(e.getSource()==jb1)
		{
			if(isOperatorClicked)
			{
				jt.setText("1");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"1");
			}
		}
		    
		else if(e.getSource()==jb2)
		{
			if(isOperatorClicked)
			{
				jt.setText("2");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"2");
			}
		}
		    
		else if(e.getSource()==jb3)
		{
			if(isOperatorClicked)
			{
				jt.setText("3");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"3");
			}
		}
		    
		else if(e.getSource()==jb4)
		{
			if(isOperatorClicked)
			{
				jt.setText("4");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"4");
			}
		}
		    
		else if(e.getSource()==jb5)
		{
			if(isOperatorClicked)
			{
				jt.setText("5");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"5");
			}
		}
		    
		else if(e.getSource()==jb6)
		{
			if(isOperatorClicked)
			{
				jt.setText("6");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"6");
			}
		}
		   
		else if(e.getSource()==jb7)
		{
			if(isOperatorClicked)
			{
				jt.setText("7");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"7");
			}
		}
		   
		else if(e.getSource()==jb8)
		{
			if(isOperatorClicked)
			{
				jt.setText("8");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"8");
			}
		}
		    
		else if(e.getSource()==jb9)
		{
			if(isOperatorClicked)
			{
				jt.setText("9");
				isOperatorClicked=false;
			}
			else
			{
				jt.setText(jt.getText()+"9");
			}
		}
		   
		else if(e.getSource()==jbAdd)
		{
			isOperatorClicked=true;
			first=jt.getText();
			symbol="+";
			
			
		}
		   
		else if(e.getSource()==jbDiff)
		{
			isOperatorClicked=true;
			first=jt.getText();
			symbol="-";
		}
		    
		else if(e.getSource()==jbMul)
		{
			isOperatorClicked=true;
			first=jt.getText();
			symbol="*";
		}
		else if(e.getSource()==jbDiv)
		{
			isOperatorClicked=true;
			first=jt.getText();
			symbol="/";
		}
		   
		else if(e.getSource()==jbDot)
		{
			jt.setText(jt.getText()+".");
		}
		    
		else if(e.getSource()==jbEq)
		{
			
			String second=jt.getText();
			
			float firstF=Float.parseFloat(first);
			float secondF=Float.parseFloat(second);
			switch(symbol) 
			{
			case "+":
				result=firstF+secondF;
				break;
			case "-":
				result=firstF-secondF;
				break;
			case "*":
				result=firstF*secondF;
				break;
			case "/":
				result=firstF/secondF;
				break;
			}
			 
			jt.setText(result+"");
		}
		else if(e.getSource()==jbCl)
		{
			jt.setText("");
		}
		
		}

}
