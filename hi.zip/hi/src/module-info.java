/**
 * 
 */
/**
 * 
 */
module hi {
	requires java.desktop;
}